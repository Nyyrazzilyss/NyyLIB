This program is free software: you can redistribute it and/or modify
it under the terms of the GNU Lesser General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.


The included DLL files are sourced from Qt 5.3.2 (http://qt.nokia.com)

The intention is to use these as a replacement for the existing
ones located on Windows systems with the Mudlet 3.0-delta package.

Sound should works with these DLLs. It quite possibly might cause other
problems, there is no warranty.

Install location: \Program Files (X86)\Mudlet