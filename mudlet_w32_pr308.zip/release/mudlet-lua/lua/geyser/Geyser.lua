--------------------------------------
--                                  --
-- The Geyser Layout Manager by guy --
--                                  --
--------------------------------------
--
-- Load code in following order:
--    Geyser.lua
--    GeyserGeyser.lua
--    GeyserUtil.lua
--    GeyserColor.lua
--    GeyserSetConstraints.lua
--    GeyserContainer.lua
--    GeyserWindow.lua
--    GeyserLabel.lua
--    GeyserGauge.lua
--    GeyserMiniConsole.lua
--    GeyserMapper.lua
--    GeyserReposition.lua
--    GeyserTests.lua



-- UNCOMMENT EVERYTHING BELOW THIS LINE FOR VERSIONS PRIOR TO 1.1.0
--myoldresizer = myoldresizer or handleWindowResizeEvent
--function handleWindowResizeEvent()
--	raiseEvent("sysWindowResizeEvent")
--end

