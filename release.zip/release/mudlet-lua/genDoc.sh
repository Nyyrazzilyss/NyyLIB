
cd lua
luadoc *.lua geyser/*.lua -d ../mudlet-lua-doc --taglet luadoc.taglet.mudlet -doclet luadoc.doclet.mudlet
